from fastapi import FastAPI, File, UploadFile, Header, HTTPException, Depends
from fastapi.responses import FileResponse
from starlette.background import BackgroundTasks

import pytesseract
from PIL import Image
import cv2
import re
import os
import json
import tempfile

app = FastAPI(title="Aadhaar OCR & Masking API")

API_KEYS = ["mysecretkey123"]

def verify_api_key(x_api_key: str = Header(None)):
    if not x_api_key or x_api_key not in API_KEYS:
        raise HTTPException(status_code=401, detail="Invalid API Key")
    return x_api_key

def remove_file(path: str):
    if os.path.exists(path):
        os.remove(path)

def clean_name(value):
    if not value:
        return value
    value = re.sub(r'[^A-Za-z\s]', '', value)
    return " ".join(value.split())

@app.post("/v1/ocr/extract-and-mask")
async def extract_and_mask(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    x_api_key: str = Depends(verify_api_key)
):

    suffix = os.path.splitext(file.filename)[1]

    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(await file.read())
        input_path = tmp.name

    try:
        image = Image.open(input_path)
        full_text = pytesseract.image_to_string(image)

        extracted = {
            "aadhaar_number": None,
            "dob": None,
            "name": None
        }

        # Aadhaar
        num_match = re.search(r'\d{4}\s?\d{4}\s?\d{4}', full_text)
        if num_match:
            extracted["aadhaar_number"] = num_match.group(0)

        # DOB
        dob_match = re.search(r'\d{2}/\d{2}/\d{4}', full_text)
        if dob_match:
            extracted["dob"] = dob_match.group(0)

        # Name (basic)
        lines = full_text.split("\n")
        for line in lines:
            if len(line.split()) >= 2 and line.isalpha():
                extracted["name"] = clean_name(line)
                break

        # Masking
        img = cv2.imread(input_path)
        h, w = img.shape[:2]

        if extracted["aadhaar_number"]:
            cv2.rectangle(img, (0, int(h * 0.6)), (w, h), (0, 0, 0), -1)

        output_path = input_path.replace(suffix, "_masked" + suffix)
        cv2.imwrite(output_path, img)

        headers = {
            "X-OCR-Data": json.dumps(extracted),
            "Access-Control-Expose-Headers": "X-OCR-Data"
        }

        background_tasks.add_task(remove_file, input_path)
        background_tasks.add_task(remove_file, output_path)

        return FileResponse(
            output_path,
            media_type=file.content_type,
            filename="masked_" + file.filename,
            headers=headers
        )

    except Exception as e:
        remove_file(input_path)
        raise HTTPException(500, str(e))


@app.get("/")
def home():
    return {"status": "OCR & Masking API Running 🚀"}